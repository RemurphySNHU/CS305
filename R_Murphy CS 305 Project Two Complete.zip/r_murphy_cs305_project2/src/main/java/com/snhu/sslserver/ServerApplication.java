package com.snhu.sslserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;



@SpringBootApplication
public class ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServerApplication.class, args);
	}

}

@RestController	
class ServerController{
	 
	
    @RequestMapping("/hash")
     String myHash() throws NoSuchAlgorithmException{
    	
    	String algorithm = "SHA-256";
    	    	    	 	
    	MessageDigest messageDigest = MessageDigest.getInstance(algorithm);
    	
    	String hashProvider = messageDigest.getAlgorithm();    	
    	
    	String data = "Robert Murphy CS 305 SNHU  DECEMBER 7 2023";
    			 
    	messageDigest.update(data.getBytes());
    	
    	byte[] hashedData = messageDigest.digest();
    	
        String checksum = bytesToHex(hashedData);           
        		
        return "<p>Data to be encoded:" + data + 
        		"</p> <p>Algorithm Used:" + hashProvider + 
        		"</p> <p>Checksum value: :" + checksum;
  
    }
    
    //utility method to convert hashed bytes to hex
    public static String bytesToHex(byte[] bytes) {
        StringBuilder out = new StringBuilder();
        for (byte b : bytes) {
            out.append(String.format("%02X", b));
        }
        return out.toString();
    }
}
